import 'package:flutter/material.dart';

import '../services/accessibility_bridge.dart';
import '../services/settings_service.dart';

// Settings: API key, base URL, model, max steps, voice language
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({
    super.key,
    required this.settingsService,
    required this.bridge,
  });

  final SettingsService settingsService;
  final AccessibilityBridge bridge;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final TextEditingController _apiKey = TextEditingController();
  final TextEditingController _baseUrl = TextEditingController();
  final TextEditingController _model = TextEditingController();
  final TextEditingController _maxSteps = TextEditingController();

  String _locale = SettingsService.defaultLocale;
  bool _obscure = true;
  bool _loaded = false;
  bool _serviceOn = false;
  late AppSettings _current;

  // Voice language options (locale code -> naam)
  static const Map<String, String> _locales = {
    'en_US': 'English (US)',
    'en_IN': 'English (India)',
    'hi_IN': 'Hindi',
    'ur_PK': 'Urdu',
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _apiKey.dispose();
    _baseUrl.dispose();
    _model.dispose();
    _maxSteps.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    _current = await widget.settingsService.load();
    _serviceOn = await widget.bridge.isServiceEnabled();
    _apiKey.text = _current.apiKey;
    _baseUrl.text = _current.baseUrl;
    _model.text = _current.model;
    _maxSteps.text = _current.maxSteps.toString();
    _locale = _locales.containsKey(_current.voiceLocale)
        ? _current.voiceLocale
        : SettingsService.defaultLocale;
    if (mounted) setState(() => _loaded = true);
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _save() async {
    final url = _baseUrl.text.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      _snack('Base URL http:// ya https:// se shuru hona chahiye.');
      return;
    }
    if (_model.text.trim().isEmpty) {
      _snack('Model ka naam khali nahi ho sakta.');
      return;
    }
    final steps =
        (int.tryParse(_maxSteps.text.trim()) ?? SettingsService.defaultMaxSteps)
            .clamp(3, 50)
            .toInt();

    await widget.settingsService.save(
      _current.copyWith(
        apiKey: _apiKey.text.trim(),
        baseUrl: url,
        model: _model.text.trim(),
        voiceLocale: _locale,
        maxSteps: steps,
      ),
    );
    if (!mounted) return;
    _snack('Settings save ho gayin.');
    Navigator.of(context).pop();
  }

  void _resetDefaults() {
    setState(() {
      _baseUrl.text = SettingsService.defaultBaseUrl;
      _model.text = SettingsService.defaultModel;
      _maxSteps.text = SettingsService.defaultMaxSteps.toString();
      _locale = SettingsService.defaultLocale;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // Privacy notice
                Card(
                  color: Colors.red.shade50,
                  child: const Padding(
                    padding: EdgeInsets.all(12),
                    child: Text(
                      'Privacy: Task ke dauran aapki screen ka text AI provider '
                      '(OpenRouter + chuna hua model) ko bheja jata hai. Password '
                      'fields chhupa di jaati hain, baaki text ja sakta hai. '
                      'Banking, password manager aur OTP screens par use na karein.',
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                TextField(
                  controller: _apiKey,
                  obscureText: _obscure,
                  autocorrect: false,
                  enableSuggestions: false,
                  decoration: InputDecoration(
                    labelText: 'OpenRouter API Key',
                    helperText: 'openrouter.ai/keys se banao (sk-or-... se shuru hoti hai)',
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off),
                      onPressed: () => setState(() => _obscure = !_obscure),
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                TextField(
                  controller: _baseUrl,
                  keyboardType: TextInputType.url,
                  autocorrect: false,
                  decoration: const InputDecoration(
                    labelText: 'Base URL',
                    helperText: 'Default: https://openrouter.ai/api/v1',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),

                TextField(
                  controller: _model,
                  autocorrect: false,
                  decoration: const InputDecoration(
                    labelText: 'Model name',
                    helperText: 'Default: openai/gpt-oss-120b:free',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),

                TextField(
                  controller: _maxSteps,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Max steps per task (3 se 50)',
                    helperText: 'Itne steps ke baad agent khud ruk jata hai',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),

                DropdownButtonFormField<String>(
                  value: _locale,
                  decoration: const InputDecoration(
                    labelText: 'Voice input ki language',
                    border: OutlineInputBorder(),
                  ),
                  items: _locales.entries
                      .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
                      .toList(),
                  onChanged: (v) => setState(() => _locale = v ?? _locale),
                ),
                const SizedBox(height: 24),

                FilledButton(onPressed: _save, child: const Text('Save karo')),
                TextButton(
                  onPressed: _resetDefaults,
                  child: const Text('URL / Model default par wapas'),
                ),
                const Divider(height: 32),

                // Accessibility section
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(
                    _serviceOn ? Icons.check_circle : Icons.error_outline,
                    color: _serviceOn ? Colors.green : Colors.orange,
                  ),
                  title: Text(_serviceOn
                      ? 'Accessibility Service ON hai'
                      : 'Accessibility Service OFF hai'),
                ),
                Wrap(
                  spacing: 8,
                  children: [
                    OutlinedButton(
                      onPressed: widget.bridge.openAccessibilitySettings,
                      child: const Text('Accessibility Settings'),
                    ),
                    OutlinedButton(
                      onPressed: widget.bridge.openAppInfo,
                      child: const Text('App Info (Restricted setting)'),
                    ),
                  ],
                ),
              ],
            ),
    );
  }
}
