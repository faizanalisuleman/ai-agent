import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../services/accessibility_bridge.dart';
import '../services/agent_controller.dart';
import '../services/settings_service.dart';
import 'settings_screen.dart';

// Main screen: Chat + Logs tabs, status card, command input, mic button
class ChatScreen extends StatefulWidget {
  const ChatScreen({
    super.key,
    required this.controller,
    required this.settingsService,
    required this.bridge,
  });

  final AgentController controller;
  final SettingsService settingsService;
  final AccessibilityBridge bridge;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with WidgetsBindingObserver {
  final TextEditingController _input = TextEditingController();
  final stt.SpeechToText _speech = stt.SpeechToText();

  bool _speechReady = false;
  bool _listening = false;
  bool _serviceOn = false;
  bool _dialogOpen = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    widget.controller.addListener(_onControllerChange);
    _checkService();
    WidgetsBinding.instance.addPostFrameCallback((_) => _ensureConsent());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    widget.controller.removeListener(_onControllerChange);
    _input.dispose();
    _speech.cancel();
    super.dispose();
  }

  // App wapas khulti hai to service status dobara check karo
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _checkService();
  }

  Future<void> _checkService() async {
    final on = await widget.bridge.isServiceEnabled();
    if (mounted) setState(() => _serviceOn = on);
  }

  // Controller ne permission maangi to dialog dikhao
  void _onControllerChange() {
    if (widget.controller.pendingReason != null && !_dialogOpen) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && widget.controller.pendingReason != null && !_dialogOpen) {
          _showSensitiveDialog();
        }
      });
    }
  }

  // ---------------- dialogs ----------------

  Future<void> _ensureConsent() async {
    final s = await widget.settingsService.load();
    if (s.consentGiven || !mounted) return;

    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Zaroori privacy notice'),
        content: const SingleChildScrollView(
          child: Text(
            'Jab aap koi task chalate hain, ye app aapki phone screen ka text '
            '(button names, chat/messages ka text, search results wagairah) '
            'AI provider ko bhejti hai (OpenRouter aur aapka chuna hua model).\n\n'
            '• Password fields chhupa di jaati hain, lekin baaki sab kuch ja sakta hai.\n'
            '• Banking, password manager ya OTP screens par agent use na karein.\n'
            '• Kuch free models prompts store ya training ke liye use kar sakte hain.\n'
            '• Logs sirf phone ki memory mein rehte hain aur sensitive data save nahi hota.\n'
            '• API key sirf aapke phone mein save hoti hai.\n\n'
            'Kya aap ye samajh kar aage badhna chahte hain?',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Nahi, band karo'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Samajh gaya, Agree'),
          ),
        ],
      ),
    );

    if (ok == true) {
      await widget.settingsService.setConsent(true);
    } else {
      SystemNavigator.pop();
    }
  }

  Future<void> _showSensitiveDialog() async {
    _dialogOpen = true;
    final reason = widget.controller.pendingReason ?? '';
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.orange),
            SizedBox(width: 8),
            Expanded(child: Text('Sensitive screen!')),
          ],
        ),
        content: Text(
          '$reason\n\n'
          'Agar aap Continue karenge to is screen ka text (password fields hide '
          'hoti hain) AI provider ko bheja jayega. Banking, password manager '
          'ya OTP par AI agent use karna risky hai.\n\n'
          'Kya continue karna hai?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Rok do'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Continue (risk meri)'),
          ),
        ],
      ),
    );
    _dialogOpen = false;
    widget.controller.answerConfirmation(ok ?? false);
  }

  // ---------------- actions ----------------

  void _send() {
    final t = _input.text.trim();
    if (t.isEmpty || widget.controller.isRunning) return;
    _input.clear();
    FocusScope.of(context).unfocus();
    widget.controller.runTask(t);
  }

  Future<void> _toggleMic() async {
    if (_listening) {
      await _speech.stop();
      if (mounted) setState(() => _listening = false);
      return;
    }

    if (!_speechReady) {
      _speechReady = await _speech.initialize(
        onStatus: (st) {
          if ((st == 'done' || st == 'notListening') && mounted) {
            setState(() => _listening = false);
          }
        },
        onError: (e) {
          if (mounted) setState(() => _listening = false);
        },
      );
    }

    if (!_speechReady) {
      _snack('Mic permission ya speech service available nahi hai.');
      return;
    }

    final s = await widget.settingsService.load();
    if (!mounted) return;
    setState(() => _listening = true);

    await _speech.listen(
      onResult: (r) {
        // Text sirf box mein aata hai; bhejne ke liye aap Send dabate ho (safety)
        setState(() {
          _input.text = r.recognizedWords;
          _input.selection = TextSelection.fromPosition(
            TextPosition(offset: _input.text.length),
          );
        });
      },
      localeId: s.voiceLocale,
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 4),
    );
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  // ---------------- status helpers ----------------

  Color _statusColor(AgentStatus s) {
    switch (s) {
      case AgentStatus.running:
        return Colors.blue;
      case AgentStatus.paused:
        return Colors.orange;
      case AgentStatus.done:
        return Colors.green;
      case AgentStatus.error:
        return Colors.red;
      case AgentStatus.stopped:
      case AgentStatus.idle:
        return Colors.grey;
    }
  }

  String _statusLabel(AgentStatus s) {
    switch (s) {
      case AgentStatus.idle:
        return 'Tayyar';
      case AgentStatus.running:
        return 'Chal raha hai';
      case AgentStatus.paused:
        return 'Permission ka intezar';
      case AgentStatus.done:
        return 'Complete';
      case AgentStatus.error:
        return 'Error';
      case AgentStatus.stopped:
        return 'Ruk gaya';
    }
  }

  String _two(int n) => n.toString().padLeft(2, '0');

  // ---------------- widgets ----------------

  Widget _serviceBanner() {
    return Card(
      color: Colors.orange.shade50,
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Accessibility Service OFF hai. Bina iske agent kaam nahi karega.',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                FilledButton(
                  onPressed: widget.bridge.openAccessibilitySettings,
                  child: const Text('Service ON karo'),
                ),
                OutlinedButton(
                  onPressed: widget.bridge.openAppInfo,
                  child: const Text('Restricted setting allow'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _statusCard(AgentController c) {
    final color = _statusColor(c.status);
    return Card(
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(Icons.circle, size: 14, color: color),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _statusLabel(c.status),
                    style: TextStyle(fontWeight: FontWeight.bold, color: color),
                  ),
                  Text(c.currentAction, maxLines: 2, overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
            if (c.isRunning)
              FilledButton.tonal(onPressed: c.stop, child: const Text('Stop')),
          ],
        ),
      ),
    );
  }

  Widget _chatList(AgentController c) {
    if (c.messages.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Command likho ya mic dabao.\n\nJaise:\n'
            '• "YouTube kholo aur lofi music search karo"\n'
            '• "Settings kholo aur Wi-Fi ka page dikhao"',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    final n = c.messages.length;
    return ListView.builder(
      reverse: true, // naya message hamesha neeche
      padding: const EdgeInsets.all(12),
      itemCount: n,
      itemBuilder: (_, i) {
        final m = c.messages[n - 1 - i];
        return Align(
          alignment: m.fromUser ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 4),
            padding: const EdgeInsets.all(12),
            constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width * 0.8,
            ),
            decoration: BoxDecoration(
              color: m.fromUser
                  ? Theme.of(context).colorScheme.primaryContainer
                  : Theme.of(context).colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(m.text),
          ),
        );
      },
    );
  }

  Widget _logList(AgentController c) {
    final n = c.logs.length;
    return Column(
      children: [
        Align(
          alignment: Alignment.centerRight,
          child: TextButton.icon(
            onPressed: n == 0 ? null : c.clearLogs,
            icon: const Icon(Icons.delete_outline),
            label: const Text('Logs saaf karo'),
          ),
        ),
        Expanded(
          child: n == 0
              ? const Center(child: Text('Abhi koi log nahi'))
              : ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemCount: n,
                  itemBuilder: (_, i) {
                    final l = c.logs[n - 1 - i];
                    final t = l.time;
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: Text(
                        '${_two(t.hour)}:${_two(t.minute)}:${_two(t.second)}  ${l.text}',
                        style: const TextStyle(fontSize: 12, fontFamily: 'monospace'),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _inputBar(AgentController c) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                IconButton(
                  onPressed: c.isRunning ? null : _toggleMic,
                  icon: Icon(
                    _listening ? Icons.mic : Icons.mic_none,
                    color: _listening ? Colors.red : null,
                  ),
                ),
                Expanded(
                  child: TextField(
                    controller: _input,
                    enabled: !c.isRunning,
                    minLines: 1,
                    maxLines: 3,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _send(),
                    decoration: InputDecoration(
                      hintText: 'Command likho...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 10,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 4),
                if (c.isRunning)
                  IconButton.filled(
                    onPressed: c.stop,
                    icon: const Icon(Icons.stop),
                  )
                else
                  IconButton.filled(
                    onPressed: _send,
                    icon: const Icon(Icons.send),
                  ),
              ],
            ),
            const Padding(
              padding: EdgeInsets.only(top: 4),
              child: Text(
                'Note: Task ke dauran screen ka text AI provider ko jata hai.',
                style: TextStyle(fontSize: 11, color: Colors.grey),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('AI Agent'),
          actions: [
            IconButton(
              icon: const Icon(Icons.settings),
              onPressed: () async {
                await Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => SettingsScreen(
                      settingsService: widget.settingsService,
                      bridge: widget.bridge,
                    ),
                  ),
                );
                _checkService();
              },
            ),
          ],
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Chat'),
              Tab(text: 'Logs'),
            ],
          ),
        ),
        body: ListenableBuilder(
          listenable: widget.controller,
          builder: (context, _) {
            final c = widget.controller;
            return Column(
              children: [
                if (!_serviceOn) _serviceBanner(),
                _statusCard(c),
                Expanded(
                  child: TabBarView(
                    children: [_chatList(c), _logList(c)],
                  ),
                ),
                _inputBar(c),
              ],
            );
          },
        ),
      ),
    );
  }
}
