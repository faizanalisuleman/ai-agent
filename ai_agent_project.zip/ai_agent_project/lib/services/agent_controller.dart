import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import '../models/agent_action.dart';
import 'accessibility_bridge.dart';
import 'ai_client.dart';
import 'safety_guard.dart';
import 'settings_service.dart';

enum AgentStatus { idle, running, paused, done, error, stopped }

class ChatMessage {
  const ChatMessage(this.fromUser, this.text);
  final bool fromUser;
  final String text;
}

class LogEntry {
  LogEntry(this.time, this.text);
  final DateTime time;
  final String text;
}

// Agent ka dimaag: screen padho -> AI se poocho -> action chalao -> repeat.
// Logs sirf memory mein rehte hain (disk par save nahi hote).
class AgentController extends ChangeNotifier {
  AgentController(this._settings, this._bridge);

  final SettingsService _settings;
  final AccessibilityBridge _bridge;

  static const String _ownPackage = 'com.example.ai_agent';

  AgentStatus status = AgentStatus.idle;
  String currentAction = 'Koi task nahi chal raha';
  String? pendingReason; // sensitive screen par user ki permission ka sawal
  final List<ChatMessage> messages = [];
  final List<LogEntry> logs = [];

  bool _stopRequested = false;
  Completer<bool>? _confirmCompleter;
  final Set<String> _approved = {};

  bool get isRunning =>
      status == AgentStatus.running || status == AgentStatus.paused;

  // ---------------- chhote helpers ----------------

  void addLog(String text) {
    // Logs mein lambe numbers (OTP/card) chhupa diye jaate hain
    logs.add(LogEntry(DateTime.now(), SafetyGuard.sanitizeForLog(text)));
    if (logs.length > 200) logs.removeAt(0);
    notifyListeners();
  }

  void clearLogs() {
    logs.clear();
    notifyListeners();
  }

  void _say(String text) {
    messages.add(ChatMessage(false, text));
    notifyListeners();
  }

  void _setStatus(AgentStatus s, String text) {
    status = s;
    currentAction = text;
    notifyListeners();
  }

  void _finish(AgentStatus s, String message) {
    status = s;
    currentAction = message;
    messages.add(ChatMessage(false, message));
    addLog('Khatam: $message');
  }

  Future<void> _sleep(int ms) => Future.delayed(Duration(milliseconds: ms));

  // Stop button
  void stop() {
    if (!isRunning) return;
    _stopRequested = true;
    addLog('Stop dabaya gaya...');
    answerConfirmation(false);
  }

  // UI se user ka jawab (sensitive screen par continue ya nahi)
  void answerConfirmation(bool ok) {
    pendingReason = null;
    final c = _confirmCompleter;
    if (c != null && !c.isCompleted) c.complete(ok);
    notifyListeners();
  }

  Future<bool> _askConfirmation(String reason, {required bool bringFront}) async {
    final completer = Completer<bool>();
    _confirmCompleter = completer;
    pendingReason = reason;
    _setStatus(AgentStatus.paused, 'Aapki permission ka intezar...');
    addLog('Sensitive screen/app mili: $reason - user se poocha');

    if (bringFront) {
      await _bridge.bringToFront('AI Agent: sensitive screen mili. App kholo aur jawab do.');
    }

    final ok = await completer.future.timeout(
      const Duration(minutes: 2),
      onTimeout: () => false,
    );
    pendingReason = null;
    _confirmCompleter = null;

    if (ok) {
      _setStatus(AgentStatus.running, 'Permission mil gayi, continue...');
      if (bringFront) {
        // Hamari app front mein hai; back dabake pichli app par wapas jao
        await _sleep(600);
        await _bridge.perform(const AgentAction(action: 'back'));
        await _sleep(800);
      }
    }
    return ok;
  }

  // ---------------- main loop ----------------

  Future<void> runTask(String rawTask) async {
    final task = rawTask.trim();
    if (task.isEmpty || isRunning) return;

    messages.add(ChatMessage(true, task));
    notifyListeners();

    final s = await _settings.load();
    if (s.apiKey.trim().isEmpty) {
      _say('Pehle Settings mein OpenRouter API key daalo.');
      return;
    }
    if (!await _bridge.isServiceEnabled()) {
      _say('Accessibility Service ON nahi hai. Upar wale orange button se ON karo.');
      return;
    }

    _stopRequested = false;
    _approved.clear();
    _setStatus(AgentStatus.running, 'Task shuru ho raha hai...');
    addLog('Task shuru (model: ${s.model}, max steps: ${s.maxSteps})');

    final ai = AiClient(
      apiKey: s.apiKey.trim(),
      baseUrl: s.baseUrl.trim(),
      model: s.model.trim(),
    );

    final history = <String>[];
    var lastSig = '';
    var repeat = 0;
    var failures = 0;

    try {
      for (var step = 1; step <= s.maxSteps; step++) {
        if (_stopRequested) {
          _finish(AgentStatus.stopped, 'Task rok diya gaya.');
          return;
        }

        // 1) Screen padho
        _setStatus(AgentStatus.running, 'Step $step: screen padh raha hoon...');
        final screenJson = await _bridge.getScreen();
        final screen = jsonDecode(screenJson) as Map<String, dynamic>;
        final screenPkg = '${screen['package'] ?? ''}';

        // 2) Safety check: AI ko bhejne se PEHLE
        final reason = SafetyGuard.checkScreen(screen);
        if (reason != null && !_approved.contains(reason)) {
          final ok = await _askConfirmation(reason, bringFront: screenPkg != _ownPackage);
          if (!ok) {
            _finish(AgentStatus.stopped, 'Sensitive screen ki wajah se task roka gaya. Screen AI ko nahi bheji gayi.');
            return;
          }
          _approved.add(reason);
          // Permission ke baad screen badal gayi hogi, dobara padho
          continue;
        }

        // 3) AI se agla action poocho
        _setStatus(AgentStatus.running, 'Step $step: AI soch raha hai...');
        final action = await ai.nextAction(
          task: task,
          screenJson: screenJson,
          history: history,
          step: step,
        );

        if (_stopRequested) {
          _finish(AgentStatus.stopped, 'Task rok diya gaya.');
          return;
        }

        currentAction = 'Step $step: ${action.describeSafe()}';
        addLog('Step $step -> ${action.describeSafe()} | ${action.reason}');

        // 4) Done?
        if (action.action == 'done') {
          _finish(
            AgentStatus.done,
            action.reason.isEmpty ? 'Kaam ho gaya.' : action.reason,
          );
          return;
        }

        // 5) Sensitive app kholne se pehle poocho
        if (action.action == 'open_app') {
          final r = SafetyGuard.checkPackage(action.appPackage);
          if (r != null && !_approved.contains(r)) {
            final ok = await _askConfirmation(r, bringFront: screenPkg != _ownPackage);
            if (!ok) {
              _finish(AgentStatus.stopped, 'Sensitive app kholne se pehle task roka gaya.');
              return;
            }
            _approved.add(r);
          }
        }

        // 6) AI bar bar wahi action de raha ho to rok do
        final sig =
            '${action.action}|${action.x}|${action.y}|${action.text}|${action.appPackage}';
        repeat = (sig == lastSig) ? repeat + 1 : 1;
        lastSig = sig;
        if (repeat >= 3 && action.action != 'wait') {
          _finish(AgentStatus.error, 'AI ek hi action bar bar de raha hai (atak gaya). Task roka gaya.');
          return;
        }

        // 7) Action chalao
        final result = await _bridge.perform(action);
        addLog('   -> ${result.ok ? "OK" : "FAIL: ${result.message}"}');

        history.add(
          '#$step ${action.describeForAi()} => ${result.ok ? "ok" : "failed: ${result.message}"}',
        );
        if (history.length > 8) history.removeAt(0);

        if (result.ok) {
          failures = 0;
        } else {
          failures++;
          if (failures >= 4) {
            _finish(AgentStatus.error, 'Lagatar 4 actions fail hue. Task roka gaya.');
            return;
          }
        }

        // 8) Screen update hone ka intezar
        await _sleep(
          action.action == 'open_app'
              ? 2500
              : action.action == 'wait'
                  ? 2000
                  : 1200,
        );
      }

      _finish(
        AgentStatus.error,
        'Max steps (${s.maxSteps}) poore ho gaye, task adhoora ho sakta hai.',
      );
    } on AiException catch (e) {
      _finish(AgentStatus.error, e.message);
    } on PlatformException catch (e) {
      _finish(AgentStatus.error, 'Phone control error: ${e.message ?? e.code}');
    } catch (_) {
      // Error ka detail log nahi karte (privacy)
      _finish(AgentStatus.error, 'Koi unexpected error aaya.');
    }
  }
}
