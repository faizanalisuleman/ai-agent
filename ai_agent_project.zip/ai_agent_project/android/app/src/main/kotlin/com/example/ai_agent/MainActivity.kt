package com.example.ai_agent

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * Flutter (Dart) aur Android (Kotlin) ke beech ka pul (bridge).
 * Dart "ai_agent/accessibility" channel se methods call karta hai.
 */
class MainActivity : FlutterActivity() {

    private val channelName = "ai_agent/accessibility"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {

                    // Service ON hai ya nahi
                    "isServiceEnabled" -> result.success(isServiceEnabled())

                    // Phone ki Accessibility settings kholo
                    "openAccessibilitySettings" -> {
                        val i = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                        result.success(true)
                    }

                    // App info kholo (Restricted setting allow karne ke liye)
                    "openAppInfo" -> {
                        val i = Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:$packageName")
                        )
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                        result.success(true)
                    }

                    // Current screen ka simplified JSON
                    "getScreen" -> {
                        val svc = AgentAccessibilityService.instance
                        if (svc == null) {
                            result.error("SERVICE_OFF", "Accessibility Service ON nahi hai", null)
                        } else {
                            result.success(svc.readScreen())
                        }
                    }

                    // tap / type / scroll / back / home / open_app / wait
                    "performAction" -> {
                        val svc = AgentAccessibilityService.instance
                        if (svc == null) {
                            result.success(
                                mapOf("ok" to false, "message" to "Accessibility Service ON nahi hai")
                            )
                        } else {
                            val action = call.argument<String>("action") ?: ""
                            val x = call.argument<Int>("x") ?: 0
                            val y = call.argument<Int>("y") ?: 0
                            val text = call.argument<String>("text") ?: ""
                            val app = call.argument<String>("app_package") ?: ""
                            svc.perform(action, x, y, text, app) { ok, msg ->
                                result.success(mapOf("ok" to ok, "message" to msg))
                            }
                        }
                    }

                    // Apni app ko front mein lao
                    "bringToFront" -> {
                        val svc = AgentAccessibilityService.instance
                        val msg = call.argument<String>("message") ?: "AI Agent"
                        svc?.bringAppToFront(msg)
                        result.success(svc != null)
                    }

                    else -> result.notImplemented()
                }
            }
    }

    // Settings.Secure mein dekho ke hamari service enabled hai ya nahi
    private fun isServiceEnabled(): Boolean {
        if (AgentAccessibilityService.instance != null) return true
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any {
            it.contains(packageName, ignoreCase = true) &&
                    it.contains("AgentAccessibilityService", ignoreCase = true)
        }
    }
}
