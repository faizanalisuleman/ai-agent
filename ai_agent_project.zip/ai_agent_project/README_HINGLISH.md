# AI Agent (Flutter + Android Accessibility Service)

## Ye project kaise kaam karta hai
1. Aap command likhte/bolte ho (Flutter chat screen).
2. App Accessibility Service se current screen padhti hai (buttons, text fields, coordinates).
3. Ye simplified screen JSON OpenRouter ke model ko jata hai.
4. Model ek JSON action deta hai: tap / type / scroll / back / home / open_app / wait / done.
5. Service wo action phone par chalati hai. Phir step 2 se repeat, jab tak `done` na aaye.

## Folder structure
```
ai_agent_project/
├── pubspec.yaml
├── .github/workflows/build_apk.yml      (cloud build, laptop ke bina)
├── lib/
│   ├── main.dart
│   ├── models/agent_action.dart
│   ├── services/
│   │   ├── settings_service.dart
│   │   ├── accessibility_bridge.dart
│   │   ├── ai_client.dart
│   │   ├── safety_guard.dart
│   │   └── agent_controller.dart
│   └── screens/
│       ├── chat_screen.dart
│       └── settings_screen.dart
└── android/app/src/main/
    ├── AndroidManifest.xml
    ├── kotlin/com/example/ai_agent/
    │   ├── MainActivity.kt
    │   └── AgentAccessibilityService.kt
    └── res/
        ├── xml/accessibility_service_config.xml
        └── values/strings.xml
```

## Build (PC par)
```
flutter create --org com.example --project-name ai_agent --platforms android ai_agent
```
Phir is zip ki `lib/`, `pubspec.yaml` aur `android/app/src/main/` ki files us naye project mein copy/replace karo
(`test/widget_test.dart` delete kar do), phir:
```
flutter pub get
flutter build apk --release
```
APK yahan milegi: `build/app/outputs/flutter-apk/app-release.apk`

## Phone par
1. APK install karo (Samsung mein Auto Blocker band karna pad sakta hai).
2. Settings > Apps > AI Agent > top-right ⋮ > **Allow restricted settings**.
3. Settings > Accessibility > Installed apps > **AI Agent** > ON.
4. App kholo, privacy notice Agree karo, Settings mein OpenRouter API key daalo.
5. Battery: App > Battery > **Unrestricted** (taake Samsung background mein band na kare).

## Safety
- Banking / password manager / OTP screens par agent pause hota hai aur permission maangta hai.
- Password fields ka text kabhi AI ko nahi jata aur unme typing block hai.
- Logs sirf memory mein hain; typed text log nahi hota; lambe numbers `****` ho jaate hain.
