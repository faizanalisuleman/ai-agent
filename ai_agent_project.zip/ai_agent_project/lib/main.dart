import 'package:flutter/material.dart';

import 'screens/chat_screen.dart';
import 'services/accessibility_bridge.dart';
import 'services/agent_controller.dart';
import 'services/settings_service.dart';

// App yahin se shuru hoti hai
void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // Teeno cheezein ek hi baar banti hain aur poori app share karti hai
  final settings = SettingsService();
  final bridge = AccessibilityBridge();
  final controller = AgentController(settings, bridge);

  runApp(AgentApp(settings: settings, bridge: bridge, controller: controller));
}

class AgentApp extends StatelessWidget {
  const AgentApp({
    super.key,
    required this.settings,
    required this.bridge,
    required this.controller,
  });

  final SettingsService settings;
  final AccessibilityBridge bridge;
  final AgentController controller;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Agent',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
      home: ChatScreen(
        controller: controller,
        settingsService: settings,
        bridge: bridge,
      ),
    );
  }
}
