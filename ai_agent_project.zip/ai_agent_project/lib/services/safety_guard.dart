// Safety checks: banking apps, password managers, OTP screens ki pehchan.
// Ye list sirf shuruaat hai - aap apne apps ke naam khud add kar sakte ho.

class SafetyGuard {
  // Package name mein ye words hon to app sensitive maani jayegi
  static const List<String> _sensitivePackageHints = [
    'bank',
    'easypaisa',
    'jazzcash',
    'sadapay',
    'nayapay',
    'paypal',
    'payoneer',
    'wallet',
    'binance',
    'bitwarden',
    'lastpass',
    '1password',
    'keepass',
    'dashlane',
    'keeper',
    'authenticator',
    'samsungpass',
  ];

  // Ye prefixes se shuru hone wale packages bhi sensitive hain
  static const List<String> _sensitivePackagePrefixes = [
    'com.hbl',
    'com.ubl',
    'com.mcb',
    'com.meezan',
    'pk.com.telenor.phoenix', // Easypaisa
    'com.techlogix.mobilinkcustomer', // JazzCash
  ];

  // Screen ke text mein ye words hon to warning
  static final RegExp _sensitiveText = RegExp(
    r'\b(otp|one[- ]time|verification code|security code|cvv|cvc|passcode|password|card number|enter pin|pin code|upi pin|atm pin)\b',
    caseSensitive: false,
  );

  // App sensitive hai to reason (String) wapas karo, warna null
  static String? checkPackage(String pkgOrName) {
    final p = pkgOrName.toLowerCase().trim();
    if (p.isEmpty) return null;
    for (final prefix in _sensitivePackagePrefixes) {
      if (p.startsWith(prefix)) {
        return 'Banking/wallet app: $pkgOrName';
      }
    }
    for (final hint in _sensitivePackageHints) {
      if (p.contains(hint)) {
        return 'Banking/wallet/password-manager app: $pkgOrName';
      }
    }
    return null;
  }

  // Screen JSON check karo: sensitive app, password field ya OTP jaisa text
  static String? checkScreen(Map<String, dynamic> screen) {
    final pkg = '${screen['package'] ?? ''}';
    final pkgReason = checkPackage(pkg);
    if (pkgReason != null) return pkgReason;

    final elements = screen['elements'];
    if (elements is List) {
      for (final e in elements) {
        if (e is! Map) continue;
        final t = '${e['text'] ?? ''} ${e['desc'] ?? ''}';
        if (t.contains('[HIDDEN]')) {
          return 'Password field screen par hai (app: $pkg)';
        }
        if (_sensitiveText.hasMatch(t)) {
          return 'OTP / password / card jaisa sensitive text mila (app: $pkg)';
        }
      }
    }
    return null;
  }

  // Logs se lambe numbers (OTP, card, phone) hata do
  static String sanitizeForLog(String s) {
    return s.replaceAll(RegExp(r'\d{4,}'), '****');
  }
}
