import 'package:shared_preferences/shared_preferences.dart';

// Saari settings ek jagah (API key, base URL, model, etc.)
class AppSettings {
  final String apiKey;
  final String baseUrl;
  final String model;
  final String voiceLocale;
  final int maxSteps;
  final bool consentGiven;

  const AppSettings({
    required this.apiKey,
    required this.baseUrl,
    required this.model,
    required this.voiceLocale,
    required this.maxSteps,
    required this.consentGiven,
  });

  AppSettings copyWith({
    String? apiKey,
    String? baseUrl,
    String? model,
    String? voiceLocale,
    int? maxSteps,
    bool? consentGiven,
  }) {
    return AppSettings(
      apiKey: apiKey ?? this.apiKey,
      baseUrl: baseUrl ?? this.baseUrl,
      model: model ?? this.model,
      voiceLocale: voiceLocale ?? this.voiceLocale,
      maxSteps: maxSteps ?? this.maxSteps,
      consentGiven: consentGiven ?? this.consentGiven,
    );
  }
}

class SettingsService {
  // Default values
  static const String defaultBaseUrl = 'https://openrouter.ai/api/v1';
  static const String defaultModel = 'openai/gpt-oss-120b:free';
  static const String defaultLocale = 'en_US';
  static const int defaultMaxSteps = 20;

  // Khali string aaye to default use karo
  String _orDefault(String? v, String fallback) {
    final t = (v ?? '').trim();
    return t.isEmpty ? fallback : t;
  }

  Future<AppSettings> load() async {
    final p = await SharedPreferences.getInstance();
    return AppSettings(
      apiKey: p.getString('api_key') ?? '',
      baseUrl: _orDefault(p.getString('base_url'), defaultBaseUrl),
      model: _orDefault(p.getString('model'), defaultModel),
      voiceLocale: _orDefault(p.getString('voice_locale'), defaultLocale),
      maxSteps: p.getInt('max_steps') ?? defaultMaxSteps,
      consentGiven: p.getBool('consent_given') ?? false,
    );
  }

  Future<void> save(AppSettings s) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('api_key', s.apiKey);
    await p.setString('base_url', s.baseUrl);
    await p.setString('model', s.model);
    await p.setString('voice_locale', s.voiceLocale);
    await p.setInt('max_steps', s.maxSteps);
    await p.setBool('consent_given', s.consentGiven);
  }

  // Sirf privacy consent save karne ke liye
  Future<void> setConsent(bool value) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('consent_given', value);
  }
}
