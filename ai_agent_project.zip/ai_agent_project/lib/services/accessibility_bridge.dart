import 'package:flutter/services.dart';

import '../models/agent_action.dart';

// Action chalane ka result
class ActionResult {
  final bool ok;
  final String message;
  const ActionResult({required this.ok, required this.message});
}

// Dart se Kotlin (AccessibilityService) tak ka pul.
// Channel ka naam MainActivity.kt wale naam se bilkul same hona chahiye.
class AccessibilityBridge {
  static const MethodChannel _channel = MethodChannel('ai_agent/accessibility');

  // Service ON hai ya nahi
  Future<bool> isServiceEnabled() async {
    try {
      return (await _channel.invokeMethod<bool>('isServiceEnabled')) ?? false;
    } on PlatformException {
      return false;
    }
  }

  Future<void> openAccessibilitySettings() async {
    await _channel.invokeMethod('openAccessibilitySettings');
  }

  Future<void> openAppInfo() async {
    await _channel.invokeMethod('openAppInfo');
  }

  // Current screen ka JSON string (service OFF ho to PlatformException aati hai)
  Future<String> getScreen() async {
    return (await _channel.invokeMethod<String>('getScreen')) ?? '{}';
  }

  // AI ka action phone par chalao
  Future<ActionResult> perform(AgentAction a) async {
    final res = await _channel.invokeMapMethod<String, dynamic>('performAction', {
      'action': a.action,
      'x': a.x,
      'y': a.y,
      'text': a.text,
      'app_package': a.appPackage,
    });
    return ActionResult(
      ok: res?['ok'] == true,
      message: '${res?['message'] ?? ''}',
    );
  }

  // Apni app ko front mein lao (best effort - fail ho to ignore)
  Future<void> bringToFront(String message) async {
    try {
      await _channel.invokeMethod('bringToFront', {'message': message});
    } on PlatformException {
      // ignore
    }
  }
}
