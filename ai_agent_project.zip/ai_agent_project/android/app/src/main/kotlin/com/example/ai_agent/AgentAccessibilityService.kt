package com.example.ai_agent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/**
 * Ye service phone ki screen padhti hai aur AI ke bataye actions
 * (tap, type, scroll, back, home, open_app) perform karti hai.
 */
class AgentAccessibilityService : AccessibilityService() {

    companion object {
        // MainActivity isi instance ke through service se baat karti hai
        @Volatile
        var instance: AgentAccessibilityService? = null

        private const val MAX_ELEMENTS = 80   // AI ko zyada se zyada itne elements bhejenge
        private const val MAX_DEPTH = 40      // UI tree ki max gehrai
        private const val MAX_TEXT = 100      // har text ki max length
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Hum events par react nahi karte, sirf command aane par screen padhte hain
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------
    // Screen ka size (pixels mein)
    // ---------------------------------------------------------------
    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    // ---------------------------------------------------------------
    // Screen padho -> simplified JSON (AI ko bhejne ke liye)
    // ---------------------------------------------------------------
    fun readScreen(): String {
        val (w, h) = screenSize()
        val out = JSONObject()
        out.put("screen_width", w)
        out.put("screen_height", h)

        val root = rootInActiveWindow
        if (root == null) {
            out.put("package", "")
            out.put("elements", JSONArray())
            out.put("note", "no_active_window")
            return out.toString()
        }

        out.put("package", root.packageName?.toString() ?: "")
        val elements = JSONArray()
        collect(root, elements, 0)
        out.put("elements", elements)
        return out.toString()
    }

    private fun collect(node: AccessibilityNodeInfo?, out: JSONArray, depth: Int) {
        if (node == null || depth > MAX_DEPTH || out.length() >= MAX_ELEMENTS) return
        if (!node.isVisibleToUser) return

        // Password field ka text kabhi nahi bhejte
        val text = if (node.isPassword) "[HIDDEN]" else (node.text?.toString() ?: "").take(MAX_TEXT)
        var desc = (node.contentDescription?.toString() ?: "").take(MAX_TEXT)
        if (desc.isBlank() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            desc = (node.hintText?.toString() ?: "").take(MAX_TEXT)
        }

        val rect = Rect()
        node.getBoundsInScreen(rect)

        val interesting = node.isClickable || node.isEditable || node.isScrollable ||
                text.isNotBlank() || desc.isNotBlank()

        if (interesting && !rect.isEmpty) {
            val e = JSONObject()
            e.put("id", out.length())
            if (text.isNotBlank()) e.put("text", text)
            if (desc.isNotBlank()) e.put("desc", desc)
            e.put("type", (node.className?.toString() ?: "").substringAfterLast('.'))
            if (node.isClickable) e.put("clickable", true)
            if (node.isEditable) e.put("editable", true)
            if (node.isScrollable) e.put("scrollable", true)
            e.put("x", rect.centerX())   // center ka x coordinate
            e.put("y", rect.centerY())   // center ka y coordinate
            e.put("w", rect.width())
            e.put("h", rect.height())
            out.put(e)
        }

        for (i in 0 until node.childCount) {
            collect(node.getChild(i), out, depth + 1)
        }
    }

    // ---------------------------------------------------------------
    // Action router: Flutter se aaya action yahan perform hota hai
    // done(ok, message) callback se result wapas jata hai
    // ---------------------------------------------------------------
    fun perform(
        action: String,
        x: Int,
        y: Int,
        text: String,
        app: String,
        done: (Boolean, String) -> Unit
    ) {
        when (action) {
            "tap" -> {
                val (w, h) = screenSize()
                if (x <= 0 || y <= 0 || x > w || y > h) {
                    done(false, "Coordinates screen ke bahar hain ($x, $y)")
                    return
                }
                tap(x.toFloat(), y.toFloat()) { ok ->
                    done(ok, if (ok) "ok" else "Tap gesture cancel ho gaya")
                }
            }
            "scroll" -> {
                scroll(text) { ok ->
                    done(ok, if (ok) "ok" else "Scroll fail (direction: up/down/left/right)")
                }
            }
            "type" -> {
                val (ok, msg) = typeText(text, x, y)
                done(ok, msg)
            }
            "back" -> {
                val ok = performGlobalAction(GLOBAL_ACTION_BACK)
                done(ok, if (ok) "ok" else "Back fail")
            }
            "home" -> {
                val ok = performGlobalAction(GLOBAL_ACTION_HOME)
                done(ok, if (ok) "ok" else "Home fail")
            }
            "open_app" -> {
                val (ok, msg) = openApp(app)
                done(ok, msg)
            }
            "wait" -> done(true, "ok")
            else -> done(false, "Unknown action: $action")
        }
    }

    // ---------------------------------------------------------------
    // Tap (gesture)
    // ---------------------------------------------------------------
    private fun tap(x: Float, y: Float, cb: (Boolean) -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        runGesture(GestureDescription.StrokeDescription(path, 0L, 80L), cb)
    }

    // ---------------------------------------------------------------
    // Scroll: "down" ka matlab hai neeche ka content dekhna (finger upar swipe)
    // ---------------------------------------------------------------
    private fun scroll(direction: String, cb: (Boolean) -> Unit) {
        val (w, h) = screenSize()
        val d = direction.lowercase().trim().ifEmpty { "down" }
        val cx = w / 2f
        val cy = h / 2f
        val path = Path()
        when (d) {
            "down" -> { path.moveTo(cx, h * 0.70f); path.lineTo(cx, h * 0.30f) }
            "up" -> { path.moveTo(cx, h * 0.30f); path.lineTo(cx, h * 0.70f) }
            "right" -> { path.moveTo(w * 0.80f, cy); path.lineTo(w * 0.20f, cy) }
            "left" -> { path.moveTo(w * 0.20f, cy); path.lineTo(w * 0.80f, cy) }
            else -> { cb(false); return }
        }
        runGesture(GestureDescription.StrokeDescription(path, 0L, 350L), cb)
    }

    private fun runGesture(stroke: GestureDescription.StrokeDescription, cb: (Boolean) -> Unit) {
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val dispatched = dispatchGesture(
            gesture,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { cb(true) }
                override fun onCancelled(gestureDescription: GestureDescription?) { cb(false) }
            },
            null
        )
        if (!dispatched) cb(false)
    }

    // ---------------------------------------------------------------
    // Type: editable field dhoondo aur text set karo
    // Text ke end mein "\n" ho to Enter (search/send) bhi dabate hain
    // ---------------------------------------------------------------
    private fun typeText(rawText: String, x: Int, y: Int): Pair<Boolean, String> {
        val root = rootInActiveWindow ?: return Pair(false, "Screen nahi mili")

        var target: AccessibilityNodeInfo? = null
        if (x > 0 && y > 0) target = findEditableAt(root, x, y, 0)
        if (target == null) {
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focused != null && focused.isEditable) target = focused
        }
        if (target == null) target = findFirstEditable(root, 0)
        if (target == null) return Pair(false, "Koi text field nahi mila")

        // Safety: password field mein kabhi type nahi karte
        if (target.isPassword) return Pair(false, "Safety: password field mein typing block hai")

        val submit = rawText.endsWith("\n")
        val clean = rawText.trimEnd('\n', '\r')

        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, clean)
        val ok = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (!ok) return Pair(false, "Text set nahi ho saka")

        if (submit && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            target.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return Pair(true, "ok")
    }

    private fun findEditableAt(node: AccessibilityNodeInfo?, x: Int, y: Int, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > MAX_DEPTH) return null
        val r = Rect()
        node.getBoundsInScreen(r)
        if (node.isEditable && r.contains(x, y)) return node
        for (i in 0 until node.childCount) {
            val found = findEditableAt(node.getChild(i), x, y, depth + 1)
            if (found != null) return found
        }
        return null
    }

    private fun findFirstEditable(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > MAX_DEPTH) return null
        if (node.isEditable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val found = findFirstEditable(node.getChild(i), depth + 1)
            if (found != null) return found
        }
        return null
    }

    // ---------------------------------------------------------------
    // App kholo: package name ya app ka naam (jaise "WhatsApp") dono chalte hain
    // ---------------------------------------------------------------
    @Suppress("DEPRECATION")
    private fun openApp(nameOrPackage: String): Pair<Boolean, String> {
        val query = nameOrPackage.trim()
        if (query.isEmpty()) return Pair(false, "App ka naam/package khali hai")

        val pm = packageManager
        var launch: Intent? = pm.getLaunchIntentForPackage(query)

        if (launch == null) {
            // Package nahi mila to app ke naam se dhoondo
            val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(mainIntent, 0)
            val q = query.lowercase()
            val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            if (match != null) {
                launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            }
        }

        if (launch == null) return Pair(false, "App nahi mili: $query")

        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            startActivity(launch)
            Pair(true, "ok")
        } catch (e: Exception) {
            Pair(false, "App open nahi ho saki")
        }
    }

    // ---------------------------------------------------------------
    // Apni app ko front mein lao (sensitive screen par permission lene ke liye)
    // ---------------------------------------------------------------
    fun bringAppToFront(message: String) {
        Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
        val i = Intent(this, MainActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
        )
        try {
            startActivity(i)
        } catch (e: Exception) {
            // Agar system ne rok diya to Toast hi kaafi hai
        }
    }
}
