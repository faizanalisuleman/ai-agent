// AI ka diya hua ek action (JSON) yahan Dart object mein badalta hai.

class AgentAction {
  final String action; // tap | type | scroll | back | home | open_app | wait | done
  final int x;
  final int y;
  final String text; // type ke liye text, scroll ke liye direction (up/down/left/right)
  final String appPackage; // open_app ke liye package name ya app ka naam
  final String reason; // AI ne ye action kyun chuna

  const AgentAction({
    required this.action,
    this.x = 0,
    this.y = 0,
    this.text = '',
    this.appPackage = '',
    this.reason = '',
  });

  static const Set<String> validActions = {
    'tap',
    'type',
    'scroll',
    'back',
    'home',
    'open_app',
    'wait',
    'done',
  };

  // JSON se object banao. Galat action ho to FormatException aayegi.
  factory AgentAction.fromJson(Map<String, dynamic> json) {
    int toInt(dynamic v) {
      if (v is num) return v.round();
      return int.tryParse('${v ?? ''}') ?? 0;
    }

    final act = '${json['action'] ?? ''}'.toLowerCase().trim();
    if (!validActions.contains(act)) {
      throw FormatException('Unknown action: $act');
    }

    return AgentAction(
      action: act,
      x: toInt(json['x']),
      y: toInt(json['y']),
      text: '${json['text'] ?? ''}',
      appPackage: '${json['app_package'] ?? ''}',
      reason: '${json['reason'] ?? ''}',
    );
  }

  // UI aur logs ke liye: typed text chhupa deta hai (privacy)
  String describeSafe() {
    switch (action) {
      case 'tap':
        return 'tap ($x, $y)';
      case 'type':
        return 'type (${text.length} characters)';
      case 'scroll':
        return 'scroll ${text.isEmpty ? "down" : text}';
      case 'open_app':
        return 'open_app $appPackage';
      default:
        return action;
    }
  }

  // AI ko "previous actions" mein bhejne ke liye
  String describeForAi() {
    switch (action) {
      case 'tap':
        return 'tap at ($x, $y)';
      case 'type':
        return 'type "$text"';
      case 'scroll':
        return 'scroll ${text.isEmpty ? "down" : text}';
      case 'open_app':
        return 'open_app "$appPackage"';
      default:
        return action;
    }
  }
}
